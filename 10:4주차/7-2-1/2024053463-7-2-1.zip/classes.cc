#include "classes.h"
#include <iostream>
#include <string>
using namespace std;

void A::test(){
    cout << "A::test()" << endl;
}

void B::test(){
    cout << "B::test()" << endl;
}

void C::test(){
    cout << "C::test()" << endl;
}
