#ifndef __MAGIC_H__
#define __MAGIC_H__
void magic_square(int n, int **matrix);
#endif